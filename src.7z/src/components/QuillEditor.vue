<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import Quill from 'quill'
import 'quill/dist/quill.snow.css'

const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: '请输入内容...'
  }
})

const emit = defineEmits(['update:modelValue'])

const editorContainer = ref<HTMLElement | null>(null)
let quill: Quill | null = null

onMounted(() => {
  if (editorContainer.value) {
    // 初始化 Quill 编辑器
    quill = new Quill(editorContainer.value, {
      theme: 'snow',
      placeholder: props.placeholder,
      modules: {
        toolbar: [
          [{ 'header': [1, 2, 3, false] }],
          ['bold', 'italic', 'underline', 'link'],
          [{ 'list': 'ordered'}, { 'list': 'bullet' }],
          ['clean'] // 清除格式按钮
        ]
      }
    })

    // 填入初始内容
    if (props.modelValue) {
      quill.root.innerHTML = props.modelValue
    }

    // 监听输入并双向绑定给父组件
    quill.on('text-change', () => {
      emit('update:modelValue', quill?.root.innerHTML)
    })
  }
})

// 监听外部数据的变化（例如切换不同项目时，更新编辑器内容）
watch(() => props.modelValue, (newVal) => {
  if (quill && newVal !== quill.root.innerHTML) {
    quill.root.innerHTML = newVal || ''
  }
})
</script>

<template>
  <div class="quill-wrapper">
    <div ref="editorContainer"></div>
  </div>
</template>

<style scoped>
.quill-wrapper {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* 深度穿透修改 Quill 默认样式，使其边框和整个系统的 UI 更搭 */
:deep(.ql-toolbar.ql-snow) {
  border: 1px solid #e5e7eb;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
  background-color: #f9fafb;
  font-family: inherit;
  padding: 12px;
}

:deep(.ql-container.ql-snow) {
  border: 1px solid #e5e7eb;
  border-top: none;
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
  font-family: inherit;
  font-size: 1rem;
  background-color: #ffffff;
}

:deep(.ql-editor) {
  min-height: 300px; /* 保证有一个舒适的默认输入高度 */
  padding: 16px;
  line-height: 1.6;
}

/* 稍微美化一下输入占位符 */
:deep(.ql-editor.ql-blank::before) {
  color: #9ca3af;
  font-style: normal;
}
</style>